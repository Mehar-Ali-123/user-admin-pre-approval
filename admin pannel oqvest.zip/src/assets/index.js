import error_img from './error_img.svg';

export {
    error_img
}